long FAR PASCAL StatusWndProc(HWND,unsigned,WPARAM,LONG );

int UpdateFactWnd ( void );
int UpdateAgendaWnd ( void );
int UpdateInstWnd ( void );
int UpdateGlobalWnd ( void );
void UpdateStatus  ( void );
void EnableStatusWindows ( void );

