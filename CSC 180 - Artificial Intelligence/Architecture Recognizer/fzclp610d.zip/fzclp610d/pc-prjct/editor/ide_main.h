
extern HICON hHourGlass;
extern HINSTANCE hInst;