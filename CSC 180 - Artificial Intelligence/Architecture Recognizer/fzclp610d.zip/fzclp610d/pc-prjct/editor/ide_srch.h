void SetUpSearch ( HWND, int );
int  StartSearch (HWND, WPARAM, LONG);
