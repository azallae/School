/*  $Header: /dist/CVS/fzclips/src/xmenu_watch.h,v 1.3 2001/08/11 21:08:39 dave Exp $  */

void WatchWindow(Widget,XtPointer,XtPointer);
void OkWatchCallback(Widget,XtPointer,XtPointer);
void WatchAllCallback(Widget,XtPointer,XtPointer);
void WatchNoneCallback(Widget,XtPointer,XtPointer);

